# Python 基础教程

## 🎯 学习目标
- 掌握Python基本语法
- 理解变量、数据类型和控制结构
- 学会函数定义和使用
- 完成简单的数据处理任务

## 📝 教程结构

### 第1章：环境搭建
```bash
# 安装Python
# Windows: 下载安装包 https://www.python.org/downloads/
# 建议安装Python 3.11+

# 验证安装
python --version

# 创建虚拟环境
python -m venv autom_env
autom_env\Scripts\activate  # Windows
# 或
source autom_env/bin/activate  # macOS/Linux
```

### 第2章：基础语法
```python
# 变量和类型
name = "陈风"
age = 20
height = 1.75
is_student = True

print(f"姓名: {name}")
print(f"年龄: {age}")

# 类型判断
print(type(name))  # <class 'str'>
print(type(age))   # <class 'int'>

# 运算符
a = 10
b = 3
print(a + b)  # 加法
print(a * b)  # 乘法
print(a // b) # 整除
print(a % b)  # 取余
```

### 第3章：控制结构
```python
# 条件判断
age = 18
if age >= 18:
    print("成年人")
elif age >= 14:
    print("青少年")
else:
    print("儿童")

# 循环
# for循环
for i in range(5):
    print(f"循环次数: {i}")

# while循环
count = 0
while count < 5:
    print(f"计数: {count}")
    count += 1

# 列表
names = ["张三", "李四", "王五"]
for name in names:
    print(f"同学: {name}")
```

### 第4章：函数
```python
def greet(name):
    """打招呼函数"""
    return f"你好, {name}!"

message = greet("陈风")
print(message)

# 参数默认值
def calculate_area(radius, pi=3.14):
    return pi * radius ** 2

area = calculate_area(5)
print(f"圆面积: {area}")
```

### 第5章：实际应用
```python
# 计算平均分
def calculate_average(scores):
    """计算平均分"""
    total = sum(scores)
    count = len(scores)
    return total / count

# 学生成绩系统
scores = [85, 92, 78, 90, 88]
average = calculate_average(scores)
print(f"平均分: {average:.2f}")

# 成绩等级
if average >= 90:
    grade = "A"
elif average >= 80:
    grade = "B"
elif average >= 70:
    grade = "C"
else:
    grade = "D"
print(f"等级: {grade}")
```

## 🔄 练习项目

### 项目1：简易计算器
```python
def calculator(num1, num2, operation):
    """简易计算器"""
    if operation == "+":
        return num1 + num2
    elif operation == "-":
        return num1 - num2
    elif operation == "*":
        return num1 * num2
    elif operation == "/":
        if num2 != 0:
            return num1 / num2
        else:
            return "除数不能为0"
    else:
        return "不支持的操作"

# 测试
result = calculator(10, 5, "+")
print(f"10 + 5 = {result}")
```

### 项目2：成绩分析器
```python
def analyze_grades():
    """成绩分析器"""
    # 录入成绩
    grades = []
    while True:
        grade = input("请输入成绩 (输入q退出): ")
        if grade.lower() == 'q':
            break
        try:
            grade = float(grade)
            grades.append(grade)
        except ValueError:
            print("无效输入，请输入数字")
    
    if grades:
        # 计算统计信息
        average = sum(grades) / len(grades)
        max_grade = max(grades)
        min_grade = min(grades)
        
        print(f"\n成绩统计:")
        print(f"平均分: {average:.2f}")
        print(f"最高分: {max_grade}")
        print(f"最低分: {min_grade}")
        print(f"人数: {len(grades)}")

# 运行程序
analyze_grades()
```

## 📚 学习资源

### 在线教程
- **菜鸟教程** - https://www.runoob.com/python/python-tutorial.html
- **廖雪峰Python** - https://www.liaoxuefeng.com/wiki/0014316089557264a6b34895bbf9b7...

### 练习平台
- **LeetCode** - https://leetcode.cn/
- **HackerRank** - https://www.hackerrank.com/
- **CodeWars** - https://www.codewars.com/

## 🎯 下一步

完成第1章练习后，继续学习：
- 文件操作
- 错误处理
- 面向对象编程
- 模块导入

**💡 提示**: 编程是实践性很强的技能，建议每天坚持写代码！
