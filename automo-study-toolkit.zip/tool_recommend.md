# 自动化专业工具推荐

## 💻 编程开发工具

### 1. Python
- **官网**: https://www.python.org/
- **版本**: 推荐3.11+
- **主要用途**: 数据分析、算法实现、人工智能、脚本编写
- **学习资源**: 
  - 菜鸟教程: https://www.runoob.com/python/python-tutorial.html
  - 廖雪峰: https://www.liaoxuefeng.com/wiki/0014316089557264a6b34895bbf9b7...

### 2. VS Code
- **官网**: https://code.visualstudio.com/
- **推荐插件**:
  - Python (ms-python.python)
  - GitLens (eamodio.gitlens)
  - Pylance (ms-python.vscode-pylance)

### 3. Git
- **官网**: https://git-scm.com/
- **GitHub**: https://github.com/
- **用途**: 版本控制、代码托管

## 🎯 仿真与设计工具

### 1. MATLAB / Octave
- **MATLAB**: https://www.mathworks.com/products/matlab.html
- **Octave**: https://www.gnu.org/software/octave/
- **主要用途**: 矩阵运算、信号处理、控制仿真

### 2. 电路仿真
- **Proteus**: 单片机电路仿真
- **Multisim**: 模拟/数字电路仿真
- **LTspice**: 电源电路仿真

### 3. 三维建模
- **SolidWorks**: https://www.solidworks.com/
- **Fusion 360**: https://www.autodesk.com/products/fusion-360/overview
- **FreeCAD**: 开源CAD软件

## 📚 学习资源网站

### 中文资源
- **B站大学**: https://www.bilibili.com/
- **慕课网**: https://www.imooc.com/
- **CSDN**: https://www.csdn.net/
- **菜鸟教程**: https://www.runoob.com/

### 英文资源
- **Coursera**: https://www.coursera.org/
- **edX**: https://www.edx.org/
- **Udacity**: https://www.udacity.com/
- **MIT OpenCourseWare**: https://ocw.mit.edu/

## 🔧 日常开发工具

### 1. 注册表管理和优化
- **CCleaner**: 系统清理
- **Process Explorer**: 进程管理 (https://learn.microsoft.com/zh-cn/sysinternals/downloads/process-explorer)

### 2. 压缩工具
- **7-Zip**: 开源压缩软件 (https://www.7-zip.org/)

### 3. PDF阅读和编辑
- **SumatraPDF**: 轻量级PDF查看器
- **Adobe Acrobat**: PDF编辑

### 4. 截图和录屏
- **Snipaste**: 截图标io工具 (https://www.snipaste.com/)
- **OBS Studio**: 屏幕录制 (https://obsproject.com/)

## 📱 移动学习工具

### 1. 笔记同步
- **Obsidian**: 双向链接笔记 (https://obsidian.md/)
- **Notion**: 多功能笔记平台 (https://www.notion.so/)

### 2. 英语学习
- **Anki**: 间隔重复记忆 (https://apps.ankiweb.net/)
- **Duolingo**: 趣味学英语

## ⚠️ 工具选择原则

### 优先级
1. **学校提供的工具** - 优先使用学校资源
2. **免费开源工具** - 降低学习成本
3. **行业标准工具** - 为就业做准备
4. **个人替代品** - 体验不同的工具

### 建议
- 不要一次性安装所有工具
- 先掌握1-2个核心工具
- 根据课程需求选择合适的工具
- 定期更新知识，淘汰旧工具
