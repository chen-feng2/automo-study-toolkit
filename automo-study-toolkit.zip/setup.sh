#自动化学习工具包安装脚本

#!/bin/bash

# 自动化学习工具包安装脚本
# 用于快速设置学习环境和仓库

echo "🚀 自动化学习工具包安装脚本"
echo "============================"

# 1. 检查Python安装
echo "📋 检查Python环境..."
if command -v python3 &> /dev/null; then
    python_version=$(python3 --version)
    echo "✅ 已安装Python 3: $python_version"
elif command -v python &> /dev/null; then
    python_version=$(python --version)
    echo "✅ 已安装Python: $python_version"
else
    echo "❌ 未找到Python，请先安装Python 3.11+"
    echo "   Windows: https://www.python.org/downloads/"
    echo "   macOS: brew install python3"
    echo "   Linux: sudo apt install python3"
    exit 1
fi

# 2. 检查Git安装
echo "🔧 检查Git环境..."
if command -v git &> /dev/null; then
    git_version=$(git --version)
    echo "✅ 已安装Git: $git_version"
else
    echo "❌ 未找到Git，请先安装Git"
    echo "   Windows: https://git-scm.com/download/win"
    echo "   macOS: brew install git"
    echo "   Linux: sudo apt install git"
    exit 1
fi

# 3. 设置天气虚拟环境
echo "🐍 设置虚拟环境..."
python -m venv venv
source venv/bin/activate  # Linux/macOS
# 对于Windows，使用: venv\Scripts\activate
echo "✅ 虚拟环境创建成功"

# 4. 安装Python包
echo "📦 安装Python包..."
pip install --upgrade pip
pip install flake8 isort black
echo "✅ Python包安装完成"

# 5. 显示提示
echo ""
echo "🎉 安装完成！"
echo "============================"
echo "📂 项目目录：$(pwd)"
echo ""
echo "🎯 下一步:"
echo "  1. 阅读 README.md"
echo "  2. 开始学习 Python 基础"
echo "  3. 开始学习 SolidWorks"
echo "  4. 使用学习计划模板"
echo ""
echo "💡 提示：每天学习30分钟，坚持很重要！"
